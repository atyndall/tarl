SimpleTimer Library for Arduino
http://playground.arduino.cc/Code/SimpleTimer
Author:  Marcello Romani
Contact: mromani@ottotecnica.com
License: GNU LGPL 2.1+